

export const data = JSON.parse(`[{
	"type": "radio",
	"soal": "Siapakah penemu baling-baling bambu",
	"a": "Doraemon",
	"b": "hanif",
	"c": "nobita",
	"d": "naruto",
	"kunci": "a",
	"score": 20
}, {
	"type": "checkbox",
	"soal": "pilihlah 3 yang benar mengenai aqil",
	"option": ["Trainer Juara Coding", "Manusia", "Anggota Avenger"],
	"kunci": ["Manusia", "Anggota Avenger"],
	"score": 20
}, {
	"type": "essay",
	"soal": "Buat gambar bintang lima dengan menggunakan coding javascript looping",
	"kunci": "*****",
	"score": 20
},{
	"type": "radio",
	"soal": "Siapakah anggota BlackPink",
	"a": "lisa",
	"b": "rossi",
	"c": "jenong",
	"d": "isoo",
	"kunci": "a",
	"score": 20
},{
	"type": "checkbox",
	"soal": "pilihlah hero avenger",
	"option": ["Hulk", "Iron Man", "Wiro Sableng"],
	"kunci": ["Hulk", "Iron Man"],
	"score": 20
},{
	"type": "radio",
	"soal": "Siapakah yang pernah dicupang aqil ",
	"a": "chelsea islan",
	"b": "lisa",
	"c": "jenong",
	"d": "isoo",
	"kunci": "a",
	"score": 20
}]`);